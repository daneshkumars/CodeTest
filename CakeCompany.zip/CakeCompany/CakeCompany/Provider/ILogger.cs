﻿namespace CakeCompany.Provider
{
    public interface ILogger
    {
        public string LogDesc { get; set; }
        public void LogError(string message);
        public void LogInfo(string message);
        public void Finallog(string message);
    }
}
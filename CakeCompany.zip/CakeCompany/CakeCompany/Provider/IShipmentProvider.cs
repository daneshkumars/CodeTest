﻿using CakeCompany.Models;

namespace CakeCompany.Provider
{
    public interface IShipmentProvider
    {
        public List<Product>? GetShipment();
    }
}
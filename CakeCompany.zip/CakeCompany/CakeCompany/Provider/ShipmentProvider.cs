﻿using System.Text;
using CakeCompany.Models;
using CakeCompany.Models.Transport;

namespace CakeCompany.Provider;

public class ShipmentProvider : IShipmentProvider
{
    private readonly IOrderProvider _orderProvider;
    private readonly ICakeProvider _cakeProvider;
    private readonly ITransportProvider _transportProvider;
    private readonly IPaymentProvider _paymentProvider;
    private readonly ILogger _logger;

    public ShipmentProvider(IOrderProvider orderProvider, ICakeProvider cakeProvider,
        ITransportProvider transportProvider, IPaymentProvider paymentProvider, ILogger logger)
    {
        _orderProvider = orderProvider;
        _cakeProvider = cakeProvider;
        _transportProvider = transportProvider;
        _paymentProvider = paymentProvider;
        _logger = logger;
    }
    public List<Product>? GetShipment()
    {        
        try
        {
            var messageBuilder = new StringBuilder();

            var orders = _orderProvider.GetLatestOrders();

            if (!orders.Any())
            {
                _logger.LogError("No order to process at the moment");
                return null;
            }

            var products = new List<Product>();
            foreach (var order in orders)
            {
                if (_orderProvider.IsOrderDeliveryPossible(order, _cakeProvider))
                {
                    _logger.LogInfo("Order:" + order.Id + "processed successul");
                    
                    if (_paymentProvider.Process(order).IsSuccessful)
                    {
                        var product = _cakeProvider.Bake(order);
                        product.OrderId = order.Id;
                        products.Add(product);
                        _logger.LogInfo("Payment processsed successful for order:" + order.Id);
                    }
                    else                      
                      _logger.LogError("Payment has not been processed for this order:") ;

                }
                else
                    _logger.LogError("Order cannot be processed at the moment");
            }

            if (products.Count > 0)
            {
                var transportmanager = new TransportManager();
                var transport = transportmanager.GetTransport(_transportProvider.CheckForAvailability(products));
                if (transport != null)
                {
                    transport.Deliver(products);
                    _logger.Finallog("Products added to Shipment through " + transportmanager.TransportType);
                    return products.ToList();
                }
                _logger.LogError("No Transportation available for this shipment");
                return null;
            }
            else
                
            return null;
        }

        catch (Exception)
        {
            _logger.LogError("There was an error while retrieving the shipment");
            return null;
        }

    }

}

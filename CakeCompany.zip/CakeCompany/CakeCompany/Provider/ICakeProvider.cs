﻿using CakeCompany.Models;

namespace CakeCompany.Provider
{
  public interface ICakeProvider
    {
      public Product Bake(Order order);
       public DateTime Check(Order order);
    }
}
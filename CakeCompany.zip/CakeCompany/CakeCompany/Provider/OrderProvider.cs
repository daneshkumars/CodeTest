﻿using System.Reflection.Metadata.Ecma335;
using CakeCompany.Models;

namespace CakeCompany.Provider;

public class OrderProvider : IOrderProvider
{
    public Order[] GetLatestOrders()
    {
        return new Order[]
        {
            new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25,true),
            new("ImportantCakeShop", DateTime.Now, 2, Cake.RedVelvet, 120.25,false)
        };
    }

    public void UpdateOrders(Order[] orders)
    {
    }

    public bool IsOrderDeliveryPossible(Order order, ICakeProvider cakeProvider)
    {
        if ((order.EstimatedDeliveryTime - cakeProvider.Check(order)).TotalMinutes < 60)
        {
            return true;
        }
        return false;
    }

}



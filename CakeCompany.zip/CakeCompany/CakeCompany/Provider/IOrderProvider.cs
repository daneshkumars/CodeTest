﻿using CakeCompany.Models;

namespace CakeCompany.Provider
{
    public interface IOrderProvider
    {
       public Order[] GetLatestOrders();
       public void UpdateOrders(Order[] orders);
       public bool IsOrderDeliveryPossible(Order order, ICakeProvider cakeProvider);
    }
}
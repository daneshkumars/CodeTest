﻿namespace CakeCompany.Models;

public enum Cake
{
    Chocolate,
    Vanilla,
    RedVelvet
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Models.Transport
{
    public class TransportManager
    {
        public string TransportType { get; set; }
        public ITransport GetTransport(string transportType)
        {
            ITransport? transport = null;   
            
            if (transportType == "Van")
            {
                TransportType = "Van";
                transport = new Van();
            }
            if (transportType == "Truck")
            {
                TransportType = "Truck";
                transport = new Truck();
            }
            else if (transportType == "Ship")
            {
                TransportType = "Ship";
                transport = new Ship();
            }
            return transport;
        }
    }
}

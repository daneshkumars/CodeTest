﻿namespace CakeCompany.Models.Cakes;

public record RedVelvet(string CakeName);
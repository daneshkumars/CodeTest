﻿namespace CakeCompany.Models.Cakes;

public record Chocolate(string CakeName);
﻿// See https://aka.ms/new-console-template for more information

using CakeCompany.Provider;

var shipmentProvider = new ShipmentProvider(new OrderProvider(),
    new CakeProvider(), 
    new TransportProvider(), 
    new PaymentProvider(),
    new ConsoleLogger());

var products = shipmentProvider.GetShipment();

Console.WriteLine("Shipment Details..." + products);

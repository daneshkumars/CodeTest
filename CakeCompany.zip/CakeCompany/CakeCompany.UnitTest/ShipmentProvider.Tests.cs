﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using CakeCompany.Models;
using CakeCompany.Provider;
using Moq;
using NUnit.Framework;

namespace CakeCompany.UnitTest
{
    [TestFixture]
    public class ShipmentProviderTests
    {
        private readonly IShipmentProvider shipmentProvider;
        private readonly Mock<IOrderProvider> orderProvider;
        private readonly ICakeProvider cakeProvider;
        private readonly ITransportProvider transportProvider;
        private readonly IPaymentProvider paymentProvider;
        private readonly ILogger logger;

        public ShipmentProviderTests()
        {
            orderProvider = new Mock<IOrderProvider>();
            cakeProvider = new CakeProvider();
            transportProvider = new TransportProvider();
            paymentProvider = new PaymentProvider();
            logger = new ConsoleLogger();

            shipmentProvider = new ShipmentProvider(orderProvider.Object, cakeProvider, transportProvider, paymentProvider, logger);
        }

        [Test]
        public void GetShipment_NoOrdersToDeliver_ReturnsNoordertoProcess()
        {
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(new Order[0]);

            var result = shipmentProvider.GetShipment();

            Assert.Null(result);
            Assert.IsTrue(logger.LogDesc.Contains("No order to process at the moment"));
        }

        [Test]
        public void GetShipment_Ordernotpaid_ReturnsPaymentNotProcessed()
        {
            var orders = new Order[]
            {
                new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25, false)
            };
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(orders);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[0], cakeProvider)).Returns(true);

            var result = shipmentProvider.GetShipment();

            Assert.Null(result);
            Assert.IsTrue(logger.LogDesc.Contains("Payment has not been processed for this order"));
        }

        [Test]
        public void GetShipment_OrderDeliveryEstimationFailed_ReturnsOrdernotprocessed()
        {
            var orders = new Order[]
             {
                new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 200.25, false)
             };
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(orders);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[0], cakeProvider)).Returns(false);

            var result = shipmentProvider.GetShipment();

            Assert.Null(result);
            Assert.IsTrue(logger.LogDesc.Contains("Order cannot be processed at the moment"));
        }

        [Test]
        public void GetShipment_OrderAddedforShimentbyVan_ReturnsOrderprocessedbyVan()
        {
            var orders = new Order[]
             {
                new("CakeBox", DateTime.Now, 5, Cake.RedVelvet, 100.25, true)
             };
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(orders);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[0], cakeProvider)).Returns(true);

            var result = shipmentProvider.GetShipment();

            Assert.That(result.Count == 1);
            Assert.IsTrue(logger.LogDesc.Contains("Products added to Shipment through Van"));
        }

        [Test]
        public void GetShipment_OrderAddedforShimentbyTruck_ReturnsOrderprocessedbyTruck()
        {
            var orders = new Order[]
             {
                new("CakeBox", DateTime.Now, 5, Cake.RedVelvet, 2000.35, true)
             };
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(orders);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[0], cakeProvider)).Returns(true);

            var result = shipmentProvider.GetShipment();

            Assert.That(result.Count == 1);
            Assert.IsTrue(logger.LogDesc.Contains("Products added to Shipment through Truck"));
        }

        [Test]
        public void GetShipment_OrderAddedforShimentbyShip_ReturnsOrderprocessedbyShip()
        {
            var orders = new Order[]
             {
                new("CakeBox", DateTime.Now, 5, Cake.RedVelvet, 8000.35, true)
             };
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(orders);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[0], cakeProvider)).Returns(true);

            var result = shipmentProvider.GetShipment();

            Assert.That(result.Count == 1);
            Assert.IsTrue(logger.LogDesc.Contains("Products added to Shipment through Ship"));
        }

        [Test]
        public void GetShipment_MultipleOrdersProcessed_ReturnMultipleProductsaddedtoShipment()
        {
            var orders = new Order[]
             {
                new("CakeBox", DateTime.Now, 5, Cake.RedVelvet, 7000.35, true),
                new("CakeBox", DateTime.Now, 5, Cake.RedVelvet, 2000.42, true),
                new("CakeBox", DateTime.Now, 5, Cake.RedVelvet, 6000.37, true)
             };
            orderProvider.Setup(x => x.GetLatestOrders()).Returns(orders);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[0], cakeProvider)).Returns(true);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[1], cakeProvider)).Returns(true);
            orderProvider.Setup(x => x.IsOrderDeliveryPossible(orders[2], cakeProvider)).Returns(true);


            var result = shipmentProvider.GetShipment();

            Assert.That(result.Count == 3);
            Assert.IsTrue(logger.LogDesc.Contains("Products added to Shipment through Ship"));
        }
    }
}
